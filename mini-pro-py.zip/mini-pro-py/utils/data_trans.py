# Function to parse author information and return a DataFrame
import pandas as pd


def parse_author_info(row):
    author_ids = row['Author(s) ID'].split('; ') if isinstance(row['Author(s) ID'], str) else []
    authors_with_affiliations = row['Authors with affiliations'].split('; ') if isinstance(
        row['Authors with affiliations'], str) else []

    author_data = []
    for author_id, author_with_affiliation in zip(author_ids, authors_with_affiliations):
        parts = author_with_affiliation.split(', ')
        author_name = parts[0]
        country = parts[-1]
        affiliations = ', '.join(parts[1:3])

        author_data.append([author_id, author_name, country, affiliations])

    return pd.DataFrame(author_data, columns=['Author(s) ID', 'Author Name', 'country', 'Affiliations'])


def trans_author_data(df):
    return pd.concat(df.apply(parse_author_info, axis=1).tolist(), ignore_index=True)


def parse_author_publication(df):
    author_publication_data_list = []
    # Populate the Author_Publication DataFrame by iterating through the original DataFrame
    for index, row in df.iterrows():
        author_ids = str(row['Author(s) ID'])  # Convert to string
        authors = author_ids.split(';') if author_ids != 'nan' else []  # Handle missing values
        eid = row['EID']
        author_publication_data_list.append(pd.DataFrame({'Author(s) ID': authors, 'PublicationEID': [eid] * len(authors)}))
    return pd.concat(author_publication_data_list, ignore_index=True)

