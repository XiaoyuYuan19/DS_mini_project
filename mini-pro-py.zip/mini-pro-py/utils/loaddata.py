# load data
# input data list of path, return the dataframe value
import pandas as pd
from icecream import ic

def load(file_paths):
    datas = []
    for f in file_paths:
    # Read the CSV file into a DataFrame.
        data = pd.read_csv(f, encoding='utf-8')
        datas.append(data)
    all_data_src = pd.concat(datas, axis=0, ignore_index=True)
    ic(all_data_src)
    return all_data_src

