from icecream import ic
import re


def show_basic_info(dfs):
    for df in dfs:
        # Display the first few rows of the dataset
        ic(df.head())
        # Get basic information about the dataset
        ic(df.info())
        # Summary statistics of numerical columns
        ic(df.describe())
        ic(df.isnull().sum())


def clean_title(text):
    # Lowercasing
    text = text.lower()
    text = re.sub(r'[^\w\s-]', '', text)
    tokens = text.split()
    clean_text = ' '.join(tokens)
    return clean_text


def clean_keywords(keywords):
    keys = keywords.lower()
    # list_of_keywords = keywords.split(';')
    # list_of_keywords = [i.lower() for i in list_of_keywords]
    return keys


def choose_topn_keywords(keyword_info_map,top_n):

    # Sort keyword_info_map by count in descending order and keep the top N
    sorted_keyword_info = sorted(keyword_info_map.items(), key=lambda x: x[1]['count'], reverse=True)[:top_n]
    keyword_info_map = {keyword_hash: info for keyword_hash, info in sorted_keyword_info}

    # Filter keywords_set to keep only the top N keywords
    # keywords_set = {keyword_hash for keyword_hash, _ in sorted_keyword_info}
    return keyword_info_map