import pandas as pd

from utils.utils import show_basic_info
from visualization.author_analysis import AuthorAffiliations, AuthorCollaborationNetwork, \
    AuthorProductivity, WorldHeatMapAuthor
from visualization.publication_analysis import YearlyPublicationTrends, SourceTitleAnalysis, citation_rank, \
    influence_factor_rank


def load_dataset_cleaned():
    print('1. load the dataset and examine its basic properties.')

    # Load the data
    author_data = pd.read_csv('data/processed/author_data.csv')
    literature_data = pd.read_csv('data/processed/literature_data.csv')
    author_publication_data = pd.read_csv('data/processed/author_publication_data.csv')
    # show the basic properties
    show_basic_info([author_data, literature_data, author_publication_data])
    return author_data, literature_data, author_publication_data


def author_analysis(top_n, author_data, author_publication_data, image_path):
    print('2. Author Analysis: '
          '\n①Author Affiliations: Visualize the distribution of authors across different affiliations to understand '
          'which institutions are most represented in the dataset.'
          '\n②Author Collaboration Network: Create a network graph to visualize author collaborations. Nodes represent '
          'authors, and edges represent collaborations. Node size can indicate the number of publications.'
          '\n③Author Productivity: Histogram or bar chart showing the distribution of the number of publications per '
          'author. ')
    AuthorAffiliations(author_data, top_n, image_path + 'author_aff.jpg')
    AuthorCollaborationNetwork(author_data.head(2000), image_path + 'author_collaboration_network.jpg')
    AuthorProductivity(author_data, author_publication_data, top_n, image_path + 'author_productivity.jpg')
    WorldHeatMapAuthor(author_data, image_path + 'world_heat_map_author.jpg')


def publication_analysis(top_n, literature_data, image_path):
    print('3. Publication Analysis:'
          '\nCitation count.'
          '\nYearly Publication Trends: Line chart showing the number of publications over the years to identify '
          'trends.'
          '\nSource Title Analysis: Bar chart or word cloud showing the most frequent source titles to identify the '
          'most common publishing outlets. ')
    citation_rank(top_n, literature_data, image_path + 'citation_rank.jpg')
    influence_factor_rank(top_n, literature_data, image_path + 'influence_factor_rank.jpg')
    YearlyPublicationTrends(literature_data, image_path + 'yearly_publication_trends.jpg')
    SourceTitleAnalysis(literature_data, top_n, image_path + 'source_title_analysis.jpg')


print('4. Keyword Analysis:'
      '\nAuthor Keywords vs. Index Keywords: Compare the distribution of author-generated keywords and index '
      'keywords. Are there commonalities or differences?'
      '\nKeyword Co-occurrence: Create a co-occurrence matrix for keywords to identify which keywords frequently '
      'appear together.'
      '\nKeyword Evolution: Visualize how the popularity of specific keywords changes over time. ')


print('5. Textual Analysis:'
      '\nAbstract Word Cloud: Create a word cloud to visualize the most common words in abstracts, which can give '
      'insights into the main topics of research.'
      '\nSentiment Analysis: Analyze the sentiment of abstracts to identify the overall sentiment of the research ('
      'e.g., positive, negative, neutral).'
      '\nText Clustering: Use clustering algorithms (e.g., K-means) to group similar abstracts based on their content.')


def main():
    top_n = 10
    image_path = 'image/vision/'
    author_data, literature_data, author_publication_data = load_dataset_cleaned()

    author_analysis(top_n, author_data, author_publication_data, image_path + 'author_analysis/')
    publication_analysis(top_n, literature_data, image_path + 'publication_analysis/')


main()