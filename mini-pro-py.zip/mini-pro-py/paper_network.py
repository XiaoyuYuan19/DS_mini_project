import pandas as pd
from utils.social_network import select_top_n_keywords, load_data
from visualization.network_visu_paper import network_visu2


def main():
    top_n = 50
    # load literature_data
    paper_series = pd.read_csv('data/processed/literature_data.csv')['References'].head(600)

    # caculate socail network parameter
    keywords_set, keyword_info_map, co_occurrence_matrix = load_data(paper_series, 'network_data/paper/')

    # Visualize co-occurrence matrix with dynamic top_n
    selected_keywords_set, selected_keywords_info, selected_co_occurrence_matrix = select_top_n_keywords(
        keywords_set, keyword_info_map, co_occurrence_matrix, top_n)

    # Visualize the co-occurrence matrix with top N keywords
    network_visu2(selected_keywords_set, selected_keywords_info, selected_co_occurrence_matrix)


main()