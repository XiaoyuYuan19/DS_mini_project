import pandas as pd
from utils.social_network import select_top_n_keywords, load_data
from visualization.network_visu import network_visu

def main():
    top_n = 10
    # load literature_data
    author_keywords_series = pd.read_csv('data/processed/literature_data.csv')['Author Keywords']

    # caculate socail network parameter
    keywords_set, keyword_info_map, co_occurrence_matrix = load_data(author_keywords_series, 'network_data/keywords/')

    # Visualize co-occurrence matrix with dynamic top_n
    selected_keywords_set, selected_keywords_info, selected_co_occurrence_matrix = select_top_n_keywords(keywords_set, keyword_info_map, co_occurrence_matrix, top_n)

    # Visualize the co-occurrence matrix with top N keywords
    network_visu(selected_keywords_set, selected_keywords_info, selected_co_occurrence_matrix)

main()