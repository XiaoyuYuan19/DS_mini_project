# Data_preprocessing
## 1. Load Data.
    load(files)
files is the list of dataset file. such as 

    list=['data/src/core_data_source.csv','data/src/expand_data_source.csv']
## 2. Choose Columns to Keep.
## 3. Handling Missing Data

## 5. Handle outliers.
## 6. Feature Engineering.
Create new features or modify existing ones to better suit your analysis. This might involve creating dummy variables, aggregating data, or engineering new attributes.
## 6. Data Transformation.

# Explorstory_data_analysis
