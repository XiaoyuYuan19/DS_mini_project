from datetime import datetime

from utils.data_trans import trans_author_data, parse_author_publication
from utils.loaddata import load
from icecream import ic

from utils.utils import clean_title, clean_keywords

file_path1 = 'data/src/core_data_source.csv'
file_path2 = 'data/src/expand_data_source.csv'


def load_data(lists):
    print('1. Load Data.')
    all_data_src = load(lists)
    return all_data_src


def choose_columns_to_keep(all_data_src):
    print('2. Choose Columns to Keep.')
    columns_to_keep = ['Author(s) ID', 'Title', 'Year', 'Source title', 'Cited by', 'Authors with affiliations',
                       'Abstract', 'Author Keywords', 'Index Keywords', 'References', 'EID']
    # Read the CSV file into a DataFrame, selecting only the desired columns.
    all_data = all_data_src[columns_to_keep]
    ic(all_data)
    return all_data


def handling_missing_data(all_data):
    print('3. Handling Missing Data')
    all_data = all_data[~all_data['Source title'].isnull()]
    all_data = all_data[~all_data['Author(s) ID'].isnull()]
    all_data = all_data[~all_data['Authors with affiliations'].isnull()]
    all_data = all_data[~all_data['References'].isnull()]
    # Fill in empty author keywords with index keywords
    all_data['Author Keywords'].fillna(all_data['Index Keywords'], inplace=True)
    all_data = all_data[~all_data['Author Keywords'].isnull()]
    all_data['Cited by'].fillna(0, inplace=True)
    ic(all_data)
    ic(all_data.isnull().sum())
    return all_data


def extract_keywords_from_abstract_and_title(all_data):
    print('4. Extract Keywords from Abstract and Title.')
    return all_data


def handle_outliers(all_data):
    print('5. Handle outliers.')
    # Applying the cleaning function to the 'Title' column
    all_data['Clean Title'] = all_data['Title'].apply(clean_title)
    # Applying the cleaning function to the 'Author Keywords' column
    all_data['Author Keywords'] = all_data['Author Keywords'].apply(clean_keywords)
    ic(all_data['Author Keywords'])
    ic(all_data.isnull().sum())
    return all_data


def feature_engineering(all_data):
    print('6. Feature Engineering.')

    # Get the current date
    current_date = datetime.now()
    current_year = current_date.year
    influence_factor = []

    # Iterate through rows using iterrows()
    for _, row in all_data.iterrows():
        years_since_publication = current_year - row['Year']
        if years_since_publication <= 0:
            influence_factor.append(row['Cited by'])
        else:
            impact_factor = row['Cited by'] / years_since_publication
            influence_factor.append(impact_factor)
    all_data['Influence Factor'] = influence_factor
    ic(all_data['Influence Factor'])
    return all_data


def data_transformation(all_data):
    print('7. Data Transformation.')
    # increase the Normal Form of database
    authors_data = all_data[['Author(s) ID', 'Authors with affiliations']].copy()
    # Apply the parsing function to each row and concatenate the DataFrames
    author_data = trans_author_data(authors_data)
    ic(author_data)

    # Create the Literature DataFrame
    literature_data = all_data[
        ['Title', 'Year', 'Source title', 'Cited by', 'Abstract', 'Author Keywords', 'Index Keywords', 'References',
         'EID', 'Influence Factor']].copy()
    # Set EID as the primary key
    # literature_data.set_index('EID', inplace=True)
    ic(literature_data)

    # Create the author_publication DataFrame
    author_publication_data = parse_author_publication(all_data)
    ic(author_publication_data)

    author_data.to_csv('data/processed/author_data.csv', index=False)
    literature_data.to_csv('data/processed/literature_data.csv', index=False)
    author_publication_data.to_csv('data/processed/author_publication_data.csv', index=False)


def main():
    files = [file_path1, file_path2]
    all_data_src = load_data(files)
    all_data = choose_columns_to_keep(all_data_src)
    all_data = handling_missing_data(all_data)
    all_data = extract_keywords_from_abstract_and_title(all_data)
    all_data = handle_outliers(all_data)
    all_data = feature_engineering(all_data)
    data_transformation(all_data)


main()
