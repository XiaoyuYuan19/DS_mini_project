import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.cluster import KMeans

# 假设你的关键词共现矩阵是一个NumPy数组，每行代表一个关键词，每列代表共现次数或相关性
# 这里使用一个随机生成的矩阵作为示例
keywords_cooccurrence_matrix = np.load('network_data/cooccurrence_matrix.npy')
print(keywords_cooccurrence_matrix)

# 使用seaborn绘制热力图
sns.heatmap(keywords_cooccurrence_matrix, cmap='YlOrRd', annot=True, fmt=".2f", cbar=False)

# 设置坐标轴标签
plt.xlabel("关键词")
plt.ylabel("关键词")

# 显示热力图
plt.show()

# 定义要分成的簇的数量（你可以根据自己的需求调整）
num_clusters = 5

# 使用K均值聚类算法
kmeans = KMeans(n_clusters=num_clusters)
cluster_labels = kmeans.fit_predict(keywords_cooccurrence_matrix)

# 输出每个关键词所属的簇
for i in range(len(cluster_labels)):
    print(f"关键词 {i} 属于簇 {cluster_labels[i]}")
